function fit = DeJong(x)
    fit=sum((x).^2);
end
